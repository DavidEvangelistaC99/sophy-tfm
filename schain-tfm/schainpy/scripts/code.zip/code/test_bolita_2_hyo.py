# TEST_BOLITA_COBRE_2
import os, sys
import datetime
import time
from schainpy.controller import Project

desc = "USRP_test"
filename = "USRP_processing.xml"
path = '/DATA_RM/DATA/CODIGO_BOLITA@2025-08-07T14-52-35/rawdata/'
figpath = '/DATA_RM/DATA/CODIGO_BOLITA@2025-08-07T14-52-35/rawdata'

## REVISION ##
## 1 ##
controllerObj = Project()
controllerObj.setup(id = '192', name='Test_USRP', description="Hola Mundo")

#######################################################################
########################## RANGO DE PLOTEO ############################
#######################################################################

# Parametros de graficos
# Cambiar valor a -3dB 

dBmin = 0 
dBmax = 120 
xmin = '0'
xmax ='24'
ymin = '0'
ymax = '60'

#######################################################################
######################## UNIDAD DE LECTURA#############################
#######################################################################

readUnitConfObj = controllerObj.addReadUnit(datatype='DigitalRFReader',
                                            path=path,
                                            startDate="2025/01/01",
                                            endDate="2025/12/30",
                                            startTime='00:00:00',
                                            endTime='23:59:59',
                                            delay=0,
                                            # set=0,
                                            online=0,
                                            # walk=1,
                                            # getByBlock = 1,
                                            # nProfileBlocks = 100,
                                            ippKm = 60)

opObj11 = readUnitConfObj.addOperation(name='printInfo')
# opObj11 = readUnitConfObj.addOperation(name='printNumberOfBlock')

# voltage -> procUnitConfObjA
# Añadir una unidad de procesamiento

## 2 ##
procUnitConfObjA = controllerObj.addProcUnit(datatype='VoltageProc', inputId=readUnitConfObj.getId())

op =  procUnitConfObjA.addOperation(name='setAttribute')
op.addParameter(name='frequency', value='70.3125e6', format='float')

op1 = procUnitConfObjA.addOperation(name='ProfileSelector')
# Cambio del valor del numero de perfiles por uno constante (199)
op1.addParameter(name='profileRangeList', value='0, 249')

# 32 Code
# code = [[1,1,1,0,1,1,0,1,1,1,1,0,0,0,1,0,1,1,1,0,1,1,0,1,0,0,0,1,1,1,0,1], [1,1,1,0,1,1,0,1,1,1,1,0,0,0,1,0,0,0,0,1,0,0,1,0,1,1,1,0,0,0,1,0]]

# 16 Code
# code = [[1,1,1,0,1,1,0,1,1,1,1,0,0,0,1,0], [1,1,1,0,1,1,0,1,0,0,0,1,1,1,0,1]]

# 8 Code
code = [[1,1,1,0,1,1,0,1], [1,1,1,0,0,0,1,0]]

## 3 ##
op2 = procUnitConfObjA.addOperation(name='Decoder', optype='other')

## 4 ##
op2.addParameter(name='code', value=code)
op2.addParameter(name='nCode', value=len(code), format='int')
op2.addParameter(name='nBaud', value=len(code[0]), format='int')

# Minimo integrar 2 perfiles por ser codigo complementario
op3 = procUnitConfObjA.addOperation(name='CohInt', optype='other') 
op3.addParameter(name='n', value=2, format='int')

#######################################################################
########## OPERACIONES DOMINIO DE LA FRECUENCIA #######################
#######################################################################

procUnitConfObjSousySpectra = controllerObj.addProcUnit(datatype='SpectraProc', inputId=procUnitConfObjA.getId())
procUnitConfObjSousySpectra.addParameter(name='nFFTPoints', value='125', format='int')
procUnitConfObjSousySpectra.addParameter(name='nProfiles', value='125', format='int')

# Remocion DC

opObj13 = procUnitConfObjSousySpectra.addOperation(name='removeDC')
opObj13.addParameter(name='mode', value='2', format='int')

#######################################################################
########## PLOTEO DOMINIO DE LA FRECUENCIA ############################
#######################################################################

# SpectraPlot

opObj11 = procUnitConfObjSousySpectra.addOperation(name='SpectraPlot', optype='external')
opObj11.addParameter(name='id', value='1', format='int')
opObj11.addParameter(name='wintitle', value='Spectra NEW', format='str')
opObj11.addParameter(name='zmin', value=dBmin)
opObj11.addParameter(name='zmax', value=dBmax)
opObj11.addParameter(name='ymin', value=ymin, format='int')
opObj11.addParameter(name='ymax', value=ymax, format='int')
opObj11.addParameter(name='showprofile', value='1', format='int')
opObj11.addParameter(name='save', value=figpath, format='str')
opObj11.addParameter(name='save_period', value=2, format='int')

#######################################################################
############################ RTI PLOT #################################
#######################################################################

'''
opObj11 = procUnitConfObjSousySpectra.addOperation(name='RTIPlot', optype='external')
opObj11.addParameter(name='id', value='2', format='int')
opObj11.addParameter(name='wintitle', value='RTIPlot', format='str')
opObj11.addParameter(name='ymin', value=ymin, format='int')
opObj11.addParameter(name='ymax', value=ymax, format='int')
opObj11.addParameter(name='xmin', value=10, format='int')
opObj11.addParameter(name='xmax', value=30, format='int')
opObj11.addParameter(name='showprofile', value='1', format='int')
opObj11.addParameter(name='save', value=figpath, format='str')
opObj11.addParameter(name='save_period', value=5, format='int')
'''

controllerObj.start()
